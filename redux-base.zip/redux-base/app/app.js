import 'babel-polyfill';
import React from 'react';
import { render } from 'react-dom';
import {browserHistory } from 'react-router';
import {syncHistoryWithStore } from 'react-router-redux';
import Bootstrap from 'bootstrap/dist/css/bootstrap.css';
import Root from './root';
import configureStore from './stores';

const store = configureStore();
const history = syncHistoryWithStore(browserHistory, store);

render(
	<Root store={store} history={history} />,
	document.getElementById('root')
);

if (module.hot) {
  module.hot.accept('./root', () => {
	const NextApp=require('./root').default;
    render(
    <NextApp store={store} history={history} />,
	document.getElementById('root')
    );
  });
}

 