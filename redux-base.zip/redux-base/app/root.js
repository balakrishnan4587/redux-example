import React  from 'react';
import { Provider } from 'react-redux';
import { Router } from 'react-router';
import routes from './routes';

function Root(props){
	const {store, history} = props;
	return(
		<Provider store={store}>
			<Router routes={routes} history={history} />
		</Provider>
	);

}
/*
Root.PropTypes={
	store:PropTypes.object.isRequired,
	history:PropTypes.object.isRequired
}*/
export default Root;