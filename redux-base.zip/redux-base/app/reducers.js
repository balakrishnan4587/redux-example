import { combineReducers } from 'redux'
import {routerReducer as routing } from 'react-router-redux';
import books from './components/book/BookPage.Reducer'

export default combineReducers({
	routing,
	booksObj: books,
  // More reducers if there are
  // can go here
});