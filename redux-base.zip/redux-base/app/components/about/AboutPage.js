import React from 'react';

const About = () => {
  return (
    <div>
        <p>about Lorem ipsum dolor sit amet, consectetur adipisicing elit. A aliquam architecto velit! Aperiam eius non odio optio</p>
    </div>
  );
};

export default About;