import React from 'react';

class ViewBooks extends React.Component{
  constructor(props){
    super(props);
  }

  
  render(){
    
    return(
      <div>
        <h3>View Bookssdd</h3>
        <ul>
          {this.props.books.map((b, i) => <li key={i}>{b.title}{b.price}</li> )}
        </ul>
       
      </div>
    )
  }
}

export default ViewBooks;
