import React from 'react';


class Book extends React.Component{
  constructor(props){
    super(props);
  }

  submitBook(input){
    this.props.createBook(input);
  }

  render(){
    let titleInput, priceInput=null;
	
    return(
      <div>
        
       
        <div>
          <h3>Add Book</h3>
          <form onSubmit={e => {
            e.preventDefault();
            var input = {title: titleInput.value, price:priceInput.value};
            this.submitBook(input);
            e.target.reset();
          }}>
			<div>
				<input type="text" name="title" ref={node => titleInput = node}/>
			</div>
			<br/>
			<div>
				<input type="text" name="price" ref={node => priceInput = node}/>
			</div>
			<br/>
			<div>
				<input type="submit" />
			</div>
          </form>
        </div>
      </div>
    )
  }
}

export default Book;
