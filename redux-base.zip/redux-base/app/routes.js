import React  from 'react';
import {Route, IndexRoute} from 'react-router';
import Home from './components/home/HomePage'
import About from './components/about/AboutPage'
import Book from './components/book/BookPage.Container'
import viewBook from './components/book/ViewBooks.Container'
import App from './components/App'

export default (
  <Route path="/" component={App}>
    <IndexRoute component={Home}></IndexRoute>
    <Route path="/about" component={About}></Route>
    <Route path="/addbook" component={Book}></Route>
	<Route path="/viewbook" component={viewBook}></Route>
	
  </Route>
);