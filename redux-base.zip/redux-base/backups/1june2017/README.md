# Setting up Webpack, Babel and React from scratch

This is a demo repository to complete tutorial in [this blog post](https://stanko.github.io/setting-up-webpack-babel-and-react-from-scratch/).

Install dependencies

```
npm install
```

To start run

```
npm run dev
```
