import React from 'react';

class ViewBooks extends React.Component{
  constructor(props){
    super(props);
  }

  
  render(){
    let titleInput, priceInput=null;
	
    return(
      <div>
        <h3>View Bookssdd</h3>
        <ul>
          {this.props.books.map((b, i) => <li key={i}>{b.title}{b.price}</li> )}
        </ul>
       
      </div>
    )
  }
}

export default ViewBooks;

/*

// Maps state from store to props
const mapStateToProps = (state, ownProps) => {
  return {
    // You can now say this.props.books
    books: state.booksObj
  }
};

// Maps actions to props
const mapDispatchToProps = (dispatch) => {
  return {
  // You can now say this.props.createBook
    createBook: book => dispatch(bookActions.createBook(book))
  }
};

// Use connect to put them together
export default connect(mapStateToProps, mapDispatchToProps)(ViewBooks);

*/